package com.teleo.artifacts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtifactsApplicationTests {

	@Test
	void contextLoads() {
	}

}
